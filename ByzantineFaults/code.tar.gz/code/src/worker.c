#include "msg/msg.h"
#include "worker.h"

int worker (int argc, char * argv[]) {


	return 0;
}
