#ifndef _SONNEK_SIMULATOR
#define _SONNEK_SIMULATOR

int client(int argc, char * argv[]);
int primary(int argc, char * argv[]);
int worker(int argc, char * argv[]);

#endif
