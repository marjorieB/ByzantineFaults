#ifndef _PRIMARY_H
#define _PRIMARY_H

void send_finalize_to_workers(int nb_workers);

int primary (int argc, char * argv[]);

#endif
