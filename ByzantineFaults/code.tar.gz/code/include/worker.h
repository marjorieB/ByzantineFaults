#ifndef _WORKER_H
#define _WORKER_H

int worker (int argc, char * argv[]);

#endif
